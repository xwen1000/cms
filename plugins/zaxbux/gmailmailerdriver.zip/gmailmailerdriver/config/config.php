<?php

return [
	/**
	 * Configuration options related to the Google APIs
	 */
	'google' => [
		/**
		 * Auth scopes used with the Google API Client. Default: https://www.googleapis.com/auth/gmail.send
		 */
		//'scopes' => [
		//	"https://www.googleapis.com/auth/gmail.send",
		//],
	],
];