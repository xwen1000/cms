#### `--option_name|-o`

multiline
option description

* Accept value: yes
* Is value required: yes
* Is multiple: no
* Default: `NULL`
